import { el } from "../utils/dom.js";

export function chip(text){
  return el("span", {class:"chip"}, text);
}

export function badge(text){
  return el("span", {class:"badge"}, text);
}

export function btn(text, cls, onClick){
  return el("button", {class:`btn ${cls||""}`.trim(), onclick:onClick}, text);
}

export function inputRow(labelText, inputEl){
  return el("div", {}, el("div", {style:"font-size:12px;color:var(--muted);margin:10px 0 6px;"}, labelText), inputEl);
}

export function difficultyDot(level){
  const map = { easy:"easy", medium:"medium", hard:"hard", elite:"elite" };
  return el("span", {class:`diffDot ${map[level]||"medium"}`});
}

export function formatDifficulty(level){
  return ({easy:"Easy", medium:"Medium", hard:"Hard", elite:"Elite"}[level] || "Medium");
}

export function fmtPercent(p){
  const x = Math.round((p || 0) * 10) / 10;
  return `${x}%`;
}
