import { el } from "../utils/dom.js";
import { navigate, getRoute } from "../router.js";

export function shell(content, activeNav = "home"){
  const top = el("div", {class:"topbar"},
    el("div", {class:"brand"},
      el("img", {src:"./assets/icon-192.png", alt:"CueLab"}),
      el("div", {},
        el("h1", {}, "CueLab"),
        el("div", {class:"subhead"}, "Personal training + knowledge vault")
      )
    ),
    el("div", {class:"row"},
      el("span", {class:"badge"}, "Offline"),
      el("span", {class:"badge"}, "Personal")
    )
  );

  const nav = bottomNav(activeNav);

  return el("div", {class:"shell"},
    top,
    el("main", {class:"page"}, content),
    nav
  );
}

export function bottomNav(active){
  const items = [
    {key:"learn", label:"Learn", ico:"📘", path:"/"},
    {key:"stats", label:"Stats", ico:"📊", path:"/stats"},
    {key:"home", label:"Home", ico:"🏠", path:"/home"},
    {key:"browse", label:"Browse", ico:"🔎", path:"/browse"},
    {key:"tools", label:"Tools", ico:"🧰", path:"/tools"}
  ];
  const inner = el("div", {class:"bottomNavInner"},
    ...items.map(it => el("div", {
      class: `navItem ${active===it.key ? "active":""}`.trim(),
      onclick: () => navigate(it.path)
    },
      el("div", {class:"ico"}, it.ico),
      el("div", {class:"txt"}, it.label)
    ))
  );

  return el("nav", {class:"bottomNav"}, inner);
}
