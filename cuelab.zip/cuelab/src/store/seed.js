// Seed data you can overwrite with your own.
// Diagrams start as null (you can upload screenshots), or later use Table Lab layouts.
export const TAGS = [
  "Shot Making",
  "Cue Ball Control",
  "Position Play",
  "Defense",
  "Banks",
  "Kicks",
  "Breaks",
  "Jump",
  "Patterns"
];

export const DEFAULT_DRILLS = [
  {
    id: "d_warmup_15",
    title: "Warmup: 15 Straight-In",
    description: "15 straight-in shots from varied distances. Focus on pre-shot routine and center-ball.",
    tags: ["Shot Making", "Fundamentals"].filter(Boolean),
    difficulty: "easy",
    estimatedMinutes: 5,
    attemptsTotal: 15,
    timerMode: "optional", // optional | forced | off
    diagram: null, // {type:'image', dataUrl: '...'} or {type:'layout', layout: {...}}
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "d_banks_cross_20",
    title: "Cross-Corner Banks (20)",
    description: "20 bank attempts. Track accuracy and longest streak. Use consistent speed + aim point.",
    tags: ["Banks", "Shot Making"],
    difficulty: "hard",
    estimatedMinutes: 8,
    attemptsTotal: 20,
    timerMode: "forced",
    diagram: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "d_position_10",
    title: "3-Ball Pattern Control (10)",
    description: "Run a simple 3-ball pattern 10 times. Mark make/miss based on completing the pattern.",
    tags: ["Patterns", "Position Play", "Cue Ball Control"],
    difficulty: "medium",
    estimatedMinutes: 10,
    attemptsTotal: 10,
    timerMode: "optional",
    diagram: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const DEFAULT_KNOWLEDGE = [
  {
    id: "k_template",
    title: "Add your notes here",
    source: "My Notes", // Tor Lowry | FXBilliards | Niels Feijen | Banking With The Beard | Sharivari | Books | My Notes
    type: "Concept",     // System | Concept | Drill | Rules | Safety | Pattern
    tags: ["Shot Making"],
    summary: "Use Knowledge Vault to store your own summaries/checklists and link them to drills.",
    checklist: [
      "Write the core idea in your own words.",
      "Add 3-7 bullets you can follow at the table.",
      "Link to a drill card so it becomes actionable."
    ],
    linkedDrillIds: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];
