import { DEFAULT_DRILLS, DEFAULT_KNOWLEDGE } from "./seed.js";
import { nowISO } from "../utils/time.js";

const KEY = "cuelab_v1";

function deepClone(x){ return JSON.parse(JSON.stringify(x)); }

function defaultState(){
  const drills = deepClone(DEFAULT_DRILLS);
  const knowledge = deepClone(DEFAULT_KNOWLEDGE);
  const drillStats = {}; // keyed by drillId
  const runs = []; // practice runs history
  const settings = {
    theme: "blue", // blue | green | darkgreen
  };
  return { version: 1, drills, knowledge, drillStats, runs, settings };
}

export function loadState(){
  try{
    const raw = localStorage.getItem(KEY);
    if(!raw) return defaultState();
    const parsed = JSON.parse(raw);
    if(!parsed || parsed.version !== 1) return defaultState();
    // basic hardening
    parsed.drills ||= [];
    parsed.knowledge ||= [];
    parsed.drillStats ||= {};
    parsed.runs ||= [];
    parsed.settings ||= { theme: "blue" };
    return parsed;
  }catch{
    return defaultState();
  }
}

export function saveState(state){
  localStorage.setItem(KEY, JSON.stringify(state));
}

export function resetState(){
  const s = defaultState();
  saveState(s);
  return s;
}

export function exportBackup(state){
  // include everything needed to restore
  return JSON.stringify({ ...state, exportedAt: nowISO(), app: "CueLab" }, null, 2);
}

export function importBackup(jsonText){
  const data = JSON.parse(jsonText);
  if(!data || data.version !== 1) throw new Error("Invalid backup (version mismatch).");
  // strip unknown big fields if needed; for now accept.
  localStorage.setItem(KEY, JSON.stringify({
    version: 1,
    drills: data.drills || [],
    knowledge: data.knowledge || [],
    drillStats: data.drillStats || {},
    runs: data.runs || [],
    settings: data.settings || { theme: "blue" }
  }));
}

export function computeDrillStats(state, drillId){
  // stored stats + derived info
  const base = state.drillStats[drillId] || {
    bestAccuracy: 0,
    bestStreakEver: 0,
    last: null
  };
  return base;
}

export function updateDrillStatFromRun(state, run){
  const s = state.drillStats[run.drillId] || { bestAccuracy: 0, bestStreakEver: 0, last: null };
  s.bestAccuracy = Math.max(s.bestAccuracy || 0, run.accuracy || 0);
  s.bestStreakEver = Math.max(s.bestStreakEver || 0, run.bestStreak || 0);
  s.last = {
    endedAt: run.endedAt,
    makes: run.makes,
    attempts: run.attempts,
    accuracy: run.accuracy,
    bestStreak: run.bestStreak,
    durationSeconds: run.durationSeconds || 0
  };
  state.drillStats[run.drillId] = s;
}

export function upsertDrill(state, drill){
  const idx = state.drills.findIndex(d => d.id === drill.id);
  drill.updatedAt = nowISO();
  if(idx >= 0) state.drills[idx] = drill;
  else state.drills.unshift(drill);
}

export function deleteDrill(state, id){
  state.drills = state.drills.filter(d => d.id !== id);
  delete state.drillStats[id];
  state.runs = state.runs.filter(r => r.drillId !== id);
  // also remove from knowledge links
  for(const k of state.knowledge){
    k.linkedDrillIds = (k.linkedDrillIds || []).filter(x => x !== id);
  }
}

export function upsertKnowledge(state, item){
  const idx = state.knowledge.findIndex(k => k.id === item.id);
  item.updatedAt = nowISO();
  if(idx >= 0) state.knowledge[idx] = item;
  else state.knowledge.unshift(item);
}

export function deleteKnowledge(state, id){
  state.knowledge = state.knowledge.filter(k => k.id !== id);
}
