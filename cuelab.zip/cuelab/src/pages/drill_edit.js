import { el } from "../utils/dom.js";
import { shell } from "../components/layout.js";
import { btn, inputRow } from "../components/ui.js";
import { navigate } from "../router.js";
import { upsertDrill, deleteDrill } from "../store/store.js";
import { TAGS } from "../store/seed.js";
import { toast } from "../utils/dom.js";
import { nowISO } from "../utils/time.js";

function uid(prefix="d"){
  return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now()}`;
}

export function DrillEditPage(ctx){
  const { state, setState } = ctx;
  const id = ctx.route.query.id;
  const isNew = !id || id === "new";
  const existing = !isNew ? (state.drills||[]).find(d=>d.id===id) : null;

  const drill = existing ? structuredClone(existing) : {
    id: uid("d"),
    title: "",
    description: "",
    tags: [],
    difficulty: "medium",
    estimatedMinutes: 5,
    attemptsTotal: 15,
    timerMode: "optional",
    diagram: null,
    createdAt: nowISO(),
    updatedAt: nowISO()
  };

  const title = el("input", {value: drill.title, placeholder:"Drill title"});
  const desc = el("textarea", {placeholder:"Short description / instructions"}, drill.description || "");
  const difficulty = el("select", {},
    el("option", {value:"easy", selected: drill.difficulty==="easy"}, "Easy"),
    el("option", {value:"medium", selected: drill.difficulty==="medium"}, "Medium"),
    el("option", {value:"hard", selected: drill.difficulty==="hard"}, "Hard"),
    el("option", {value:"elite", selected: drill.difficulty==="elite"}, "Elite")
  );
  const est = el("input", {type:"number", min:"0", value:String(drill.estimatedMinutes || 0)});
  const attempts = el("input", {type:"number", min:"1", value:String(drill.attemptsTotal || 10)});
  const timerMode = el("select", {},
    el("option", {value:"optional", selected: drill.timerMode==="optional"}, "Optional"),
    el("option", {value:"forced", selected: drill.timerMode==="forced"}, "Forced"),
    el("option", {value:"off", selected: drill.timerMode==="off"}, "Off")
  );

  const tagWrap = el("div", {class:"chips"},
    ...TAGS.map(t => {
      const selected = (drill.tags||[]).includes(t);
      return el("span", {
        class:"chip",
        style: selected ? "border-color:rgba(34,211,238,.35);background:rgba(34,211,238,.10)" : "",
        onclick: ()=> {
          if((drill.tags||[]).includes(t)) drill.tags = drill.tags.filter(x=>x!==t);
          else drill.tags = [...(drill.tags||[]), t];
          ctx.render();
        }
      }, t);
    })
  );

  // Diagram upload (Stage 1)
  const preview = el("div", {class:"diagram", style:"height:180px;margin-top:10px"},
    drill.diagram?.type === "image" ? el("img", {src: drill.diagram.dataUrl, alt:"Diagram"}) :
    el("div", {style:"font-size:12px;color:rgba(231,233,237,.7)"}, "Upload diagram screenshot (or use Table Lab later)")
  );

  const file = el("input", {type:"file", accept:"image/*", onchange: async (e)=>{
    const f = e.target.files?.[0];
    if(!f) return;
    const reader = new FileReader();
    reader.onload = ()=> {
      drill.diagram = { type:"image", dataUrl: String(reader.result) };
      toast("Diagram added.");
      ctx.render();
    };
    reader.readAsDataURL(f);
  }});

  const save = ()=>{
    drill.title = title.value.trim() || "Untitled Drill";
    drill.description = desc.value.trim();
    drill.difficulty = difficulty.value;
    drill.estimatedMinutes = Math.max(0, Number(est.value || 0));
    drill.attemptsTotal = Math.max(1, Number(attempts.value || 1));
    drill.timerMode = timerMode.value;

    const next = structuredClone(state);
    upsertDrill(next, drill);
    setState(next);
    toast("Saved.");
    navigate(`/drill?id=${encodeURIComponent(drill.id)}`);
  };

  const del = ()=>{
    if(isNew){
      navigate("/browse");
      return;
    }
    if(!confirm("Delete this drill and its history?")) return;
    const next = structuredClone(state);
    deleteDrill(next, drill.id);
    setState(next);
    toast("Deleted.");
    navigate("/browse");
  };

  const content = el("div", {},
    el("div", {class:"h2"}, isNew ? "Add Drill" : "Edit Drill"),
    el("div", {class:"card pad"},
      inputRow("Title", title),
      inputRow("Description", desc),
      el("div", {class:"row wrap"},
        el("div", {style:"flex:1;min-width:160px"}, inputRow("Difficulty", difficulty)),
        el("div", {style:"flex:1;min-width:140px"}, inputRow("Estimated minutes", est))
      ),
      el("div", {class:"row wrap"},
        el("div", {style:"flex:1;min-width:160px"}, inputRow("Attempts (fixed)", attempts)),
        el("div", {style:"flex:1;min-width:140px"}, inputRow("Timer mode", timerMode))
      ),
      el("div", {style:"font-size:12px;color:var(--muted);margin-top:10px"}, "Tags"),
      tagWrap,
      el("div", {style:"margin-top:12px"}),
      el("div", {style:"font-size:12px;color:var(--muted)"}, "Diagram (Stage 1: upload screenshot)"),
      preview,
      el("div", {style:"margin-top:10px"}, file),
      el("div", {style:"margin-top:14px", class:"btnRow"},
        btn("Save", "primary", save),
        btn(isNew ? "Cancel" : "Delete", isNew ? "" : "danger", del)
      )
    ),
    !isNew ? el("div", {class:"card pad", style:"margin-top:12px"},
      el("div", {style:"font-size:12px;color:var(--muted)"},
        "Tip: Use Tools → Table Lab to build layouts later, then we’ll attach them to drills (Stage 3)."
      )
    ) : null
  );

  return shell(content, "browse");
}
