import { el } from "../utils/dom.js";
import { shell } from "../components/layout.js";
import { btn } from "../components/ui.js";
import { navigate } from "../router.js";
import { nowISO } from "../utils/time.js";
import { updateDrillStatFromRun } from "../store/store.js";
import { toast } from "../utils/dom.js";

export function DrillRunPage(ctx){
  const { state, setState } = ctx;
  const id = ctx.route.query.id;
  const drill = (state.drills||[]).find(d=>d.id===id);
  if(!drill){
    return shell(el("div", {class:"card pad"}, "Drill not found."), "browse");
  }

  // Timer settings
  let timerEnabled = drill.timerMode === "forced" ? true : false;
  if(drill.timerMode === "optional"){
    timerEnabled = (ctx.route.query.timer === "1");
  }

  let makes = 0;
  let attempts = 0;
  let streak = 0;
  let bestStreak = 0;

  const startedAt = new Date();
  let interval = null;

  const timeEl = el("div", {style:"font-size:12px;color:var(--muted)"}, timerEnabled ? "00:00" : "Timer off");
  const titleEl = el("div", {style:"font-weight:700;font-size:16px"}, drill.title);
  const counterEl = el("div", {style:"font-size:12px;color:var(--muted)"}, `0 / ${drill.attemptsTotal} attempts`);
  const bigEl = el("div", {style:"font-size:44px;font-weight:800;letter-spacing:.5px;margin:10px 0 6px"}, "0%");
  const subEl = el("div", {style:"font-size:12px;color:var(--muted)"}, "Best streak this run: 0");

  if(timerEnabled){
    interval = setInterval(()=>{
      const sec = Math.floor((Date.now() - startedAt.getTime())/1000);
      const m = String(Math.floor(sec/60)).padStart(2,"0");
      const s = String(sec%60).padStart(2,"0");
      timeEl.textContent = `${m}:${s}`;
    }, 250);
  }

  function updateUI(){
    counterEl.textContent = `${attempts} / ${drill.attemptsTotal} attempts`;
    const acc = attempts ? (makes/attempts)*100 : 0;
    bigEl.textContent = `${Math.round(acc)}%`;
    subEl.textContent = `Best streak this run: ${bestStreak}`;
  }

  function record(isMake){
    attempts += 1;
    if(isMake){
      makes += 1;
      streak += 1;
      bestStreak = Math.max(bestStreak, streak);
    }else{
      streak = 0;
    }
    updateUI();

    if(attempts >= drill.attemptsTotal){
      finish();
    }
  }

  function finish(){
    if(interval) clearInterval(interval);
    const endedAt = new Date();
    const durationSeconds = timerEnabled ? Math.max(0, Math.floor((endedAt - startedAt)/1000)) : 0;
    const accuracy = attempts ? (makes/attempts)*100 : 0;

    const run = {
      id: `r_${Date.now()}`,
      drillId: drill.id,
      startedAt: startedAt.toISOString(),
      endedAt: endedAt.toISOString(),
      makes,
      attempts,
      accuracy,
      bestStreak,
      durationSeconds
    };

    // persist
    const next = structuredClone(state);
    next.runs = [...(next.runs||[]), run];
    updateDrillStatFromRun(next, run);
    setState(next);

    navigate(`/run/result?id=${encodeURIComponent(drill.id)}&rid=${encodeURIComponent(run.id)}`);
  }

  const top = el("div", {class:"card pad cardGlowPurple"},
    el("div", {class:"row", style:"justify-content:space-between;align-items:flex-start"},
      el("div", {}, titleEl, counterEl, timeEl),
      el("div", {},
        drill.timerMode === "optional"
          ? btn(timerEnabled ? "Timer: on" : "Timer: off", "smallBtn", ()=>{
              timerEnabled = !timerEnabled;
              // restart screen with timer param to keep logic simple
              navigate(`/run?id=${encodeURIComponent(drill.id)}&timer=${timerEnabled?1:0}`);
            })
          : el("div", {style:"font-size:12px;color:var(--muted)"}, drill.timerMode === "forced" ? "Timer forced" : "Timer off")
      )
    ),
    el("div", {style:"text-align:center;margin-top:10px"},
      bigEl,
      subEl
    )
  );

  const buttons = el("div", {class:"card pad", style:"margin-top:12px"},
    el("div", {class:"btnRow"},
      btn("MAKE", "good", ()=>record(true)),
      btn("MISS", "danger", ()=>record(false))
    ),
    el("div", {style:"margin-top:10px"},
      btn("Quit", "", ()=>{
        if(interval) clearInterval(interval);
        toast("Run cancelled.");
        navigate(`/drill?id=${encodeURIComponent(drill.id)}`);
      })
    )
  );

  return shell(el("div", {},
    el("div", {class:"h2"}, "Drill Run"),
    top,
    buttons
  ), "browse");
}

export function DrillRunResultPage(ctx){
  const { state } = ctx;
  const id = ctx.route.query.id;
  const rid = ctx.route.query.rid;
  const drill = (state.drills||[]).find(d=>d.id===id);
  const run = (state.runs||[]).find(r=>r.id===rid);
  if(!drill || !run){
    return shell(el("div", {class:"card pad"}, "Result not found."), "browse");
  }

  const acc = Math.round(run.accuracy);
  const summary = el("div", {class:"card pad cardGlowCyan"},
    el("div", {style:"font-weight:800;font-size:44px;text-align:center"}, `${acc}%`),
    el("div", {style:"text-align:center;color:var(--muted);font-size:13px"}, `${run.makes}/${run.attempts} • Best streak ${run.bestStreak}`),
    run.durationSeconds ? el("div", {style:"text-align:center;color:var(--muted);font-size:13px;margin-top:4px"}, `Time: ${Math.floor(run.durationSeconds/60)}m ${run.durationSeconds%60}s`) : null
  );

  const actions = el("div", {class:"card pad", style:"margin-top:12px"},
    btn("Back to Drill", "primary full", ()=>navigate(`/drill?id=${encodeURIComponent(drill.id)}`)),
    el("div", {style:"margin-top:10px"}),
    btn("Browse", "full", ()=>navigate("/browse"))
  );

  return shell(el("div", {},
    el("div", {class:"h2"}, "Result"),
    summary,
    actions
  ), "browse");
}
