import { el } from "../utils/dom.js";
import { shell } from "../components/layout.js";
import { btn } from "../components/ui.js";
import { exportBackup, importBackup, resetState } from "../store/store.js";
import { toast } from "../utils/dom.js";
import { navigate } from "../router.js";

function downloadText(filename, text){
  const blob = new Blob([text], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 1500);
}

export function BackupPage(ctx){
  const { state } = ctx;
  const content = el("div", {},
    el("div", {class:"h2"}, "Backup"),
    el("div", {class:"card pad cardGlowGreen"},
      el("div", {style:"font-weight:800"}, "Export your CueLab data"),
      el("div", {style:"font-size:13px;color:rgba(231,233,237,.78);margin-top:6px"},
        "This exports drills, stats, runs, and knowledge as a JSON file you can store anywhere."
      ),
      el("div", {style:"margin-top:12px"},
        btn("Download Backup JSON", "primary full", ()=>{
          const text = exportBackup(state);
          const stamp = new Date().toISOString().slice(0,10);
          downloadText(`cuelab-backup-${stamp}.json`, text);
          toast("Backup downloaded.");
        })
      )
    )
  );
  return shell(content, "tools");
}

export function RestorePage(ctx){
  const { setState } = ctx;
  const file = el("input", {type:"file", accept:"application/json"});
  const content = el("div", {},
    el("div", {class:"h2"}, "Restore"),
    el("div", {class:"card pad cardGlowDanger"},
      el("div", {style:"font-weight:800"}, "Import a backup JSON"),
      el("div", {style:"font-size:13px;color:rgba(231,233,237,.78);margin-top:6px"},
        "Restoring will replace your current local data."
      ),
      el("div", {style:"margin-top:10px"}, file),
      el("div", {style:"margin-top:12px"},
        btn("Restore Now", "danger full", async ()=>{
          const f = file.files?.[0];
          if(!f){ toast("Choose a JSON file first."); return; }
          if(!confirm("Replace your current CueLab data with this backup?")) return;
          const text = await f.text();
          try{
            importBackup(text);
            // reload from storage by forcing a refresh
            toast("Restored. Reloading…");
            setTimeout(()=>location.reload(), 600);
          }catch(e){
            toast("Restore failed: " + (e?.message || "Unknown error"));
          }
        })
      )
    ),
    el("div", {class:"card pad", style:"margin-top:12px"},
      btn("Reset to factory defaults", "full", ()=>{
        if(!confirm("Reset CueLab to defaults? This wipes local data.")) return;
        resetState();
        toast("Reset. Reloading…");
        setTimeout(()=>location.reload(), 600);
      })
    )
  );
  return shell(content, "tools");
}
