import { el } from "../utils/dom.js";
import { chip, badge } from "../components/ui.js";
import { shell } from "../components/layout.js";
import { fmtDuration } from "../utils/time.js";

function levelFromScore(score){
  // Simple personal ladder (you can change later)
  if(score >= 800) return {name:"Elite", next:"", pointsToNext:0};
  if(score >= 700) return {name:"Tournament", next:"Elite", pointsToNext:800-score};
  if(score >= 600) return {name:"Advanced", next:"Tournament", pointsToNext:700-score};
  if(score >= 500) return {name:"Intermediate", next:"Advanced", pointsToNext:600-score};
  return {name:"Beginner", next:"Intermediate", pointsToNext:500-score};
}

export function HomePage(ctx){
  const { state } = ctx;

  // Very simple rating: average of best accuracies scaled
  const stats = Object.values(state.drillStats || {});
  const avgBest = stats.length ? (stats.reduce((a,s)=>a+(s.bestAccuracy||0),0)/stats.length) : 0;
  const rating = Math.round(300 + (avgBest * 5)); // 300..800-ish
  const lvl = levelFromScore(rating);

  const skillCard = el("div", {class:"card pad cardGlowPurple"},
    el("div", {class:"kpi"},
      el("div", {},
        el("div", {class:"label"}, "Skill Level"),
        el("div", {class:"value"}, lvl.name),
        el("div", {class:"small"}, `Estimated rating: ${rating}`)
      ),
      el("div", {style:"text-align:right"},
        badge(lvl.next ? `Next: ${lvl.next}` : "Top tier"),
        el("div", {class:"small", style:"margin-top:8px"}, lvl.next ? `${lvl.pointsToNext} pts to next` : "Keep refining")
      )
    ),
    el("div", {class:"divider"}),
    el("div", {style:"font-size:12px;color:var(--muted)"},
      "This is your personal CueLab rating (based on your drill bests). You can change the formula anytime."
    )
  );

  const recCard = el("div", {class:"card pad cardGlowCyan", style:"margin-top:12px"},
    el("div", {class:"h3"}, "Recommended Training Focus"),
    el("div", {class:"desc"},
      "CueLab will recommend the weakest area once you have more drill history. For now: train one bank drill + one position drill today."
    ),
    el("div", {class:"divider"}),
    el("div", {class:"chips"},
      chip("Banks"), chip("Cue Ball Control"), chip("Defense")
    )
  );

  const categories = [
    {name:"Fundamentals", level:"Intermediate", glow:"cardGlowPurple"},
    {name:"Aiming & Shot Making", level:"Intermediate", glow:"cardGlowCyan"},
    {name:"Cue Ball Control", level:"Intermediate", glow:"cardGlowGreen"},
    {name:"Position Play & Runouts", level:"Beginner", glow:"cardGlowAmber"},
    {name:"Defense", level:"Beginner", glow:"cardGlowPurple"},
    {name:"Banks / Kicks", level:"Intermediate", glow:"cardGlowDanger"}
  ];

  const catCard = el("div", {class:"card pad", style:"margin-top:12px"},
    el("div", {class:"h3"}, "Skills & Training"),
    el("div", {style:"display:flex;flex-direction:column;gap:10px;margin-top:8px"},
      ...categories.map(c => el("div", {class:`card pad soft ${c.glow}`.trim()},
        el("div", {class:"kvRow"},
          el("div", {},
            el("div", {style:"font-weight:700"}, c.name),
            el("div", {style:"font-size:12px;color:var(--muted);margin-top:2px"}, "Series rated")
          ),
          el("div", {style:"text-align:right"},
            el("div", {style:"font-weight:700"}, c.level),
            el("div", {style:"font-size:12px;color:var(--muted);margin-top:2px"}, "—")
          )
        )
      ))
    )
  );

  return shell(el("div", {},
    el("div", {class:"h2"}, "Home"),
    skillCard,
    recCard,
    catCard
  ), "home");
}
