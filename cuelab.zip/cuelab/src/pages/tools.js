import { el } from "../utils/dom.js";
import { shell } from "../components/layout.js";
import { navigate } from "../router.js";

function toolCard(glowClass, ico, title, subtitle, onClick){
  return el("div", {class:`card pad ${glowClass}`.trim(), onclick:onClick, style:"cursor:pointer"},
    el("div", {style:"display:flex;gap:12px;align-items:center"},
      el("div", {style:"font-size:26px"}, ico),
      el("div", {},
        el("div", {style:"font-weight:800"}, title),
        el("div", {style:"font-size:12px;color:var(--muted);margin-top:2px"}, subtitle)
      )
    )
  );
}

export function ToolsPage(ctx){
  const content = el("div", {},
    el("div", {class:"h2"}, "Tools"),

    el("div", {class:"h3"}, "Knowledge Vault"),
    el("div", {class:"grid2"},
      toolCard("cardGlowPurple", "🧠", "Library", "Your notes/systems + linked drills", ()=>navigate("/library")),
      toolCard("cardGlowCyan", "➕", "Quick Add Note", "Add a new knowledge entry", ()=>navigate("/library/new"))
    ),

    el("div", {class:"h3", style:"margin-top:14px"}, "Image / Layout"),
    el("div", {class:"grid2"},
      toolCard("cardGlowCyan", "📐", "Table Lab", "Build layouts (balls/lines) — coming next", ()=>navigate("/table-lab")),
      toolCard("cardGlowAmber", "🖼️", "Attach Diagram", "Edit a drill to upload a screenshot", ()=>navigate("/browse"))
    ),

    el("div", {class:"h3", style:"margin-top:14px"}, "Data"),
    el("div", {class:"grid2"},
      toolCard("cardGlowGreen", "📦", "Backup", "Export your drills + stats (JSON)", ()=>navigate("/backup")),
      toolCard("cardGlowDanger", "🔁", "Restore", "Import a backup JSON", ()=>navigate("/restore"))
    ),

    el("div", {class:"h3", style:"margin-top:14px"}, "Referee Utilities"),
    el("div", {class:"grid2"},
      toolCard("cardGlowPurple", "⏱️", "Shot Clock", "Simple timer (later)", ()=>alert("Coming soon")),
      toolCard("cardGlowCyan", "📏", "Rules Quick View", "WPA quick reference (later)", ()=>alert("Coming soon"))
    )
  );

  return shell(content, "tools");
}
