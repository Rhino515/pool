import { el } from "../utils/dom.js";
import { shell } from "../components/layout.js";
import { btn } from "../components/ui.js";
import { filterRunsByRange, summarize, weekBuckets, mostPracticed, categoryBalance } from "../utils/stats.js";
import { fmtDuration, weekdayShort } from "../utils/time.js";
import { navigate } from "../router.js";

export function StatsPage(ctx){
  const { state, setState } = ctx;

  const range = ctx.route.query.range || "week"; // week | month | all
  const runs = filterRunsByRange(state.runs || [], range);

  const drillsById = Object.fromEntries((state.drills||[]).map(d=>[d.id,d]));
  const sum = summarize(runs);
  const wb = weekBuckets(state.runs || []);
  const most = mostPracticed(runs, drillsById);
  const bal = categoryBalance(runs, drillsById);

  let activeDay = ctx.route.query.day || wb.keys[0];

  const header = el("div", {class:"row wrap", style:"justify-content:space-between;align-items:flex-end"},
    el("div", {},
      el("div", {class:"h2"}, "Practice Statistics"),
      el("div", {style:"font-size:12px;color:var(--muted)"}, "Your personal training log")
    ),
    el("div", {class:"row"},
      el("select", {
        onchange: (e)=>navigate(`/stats?range=${e.target.value}`),
        value: range
      },
        el("option", {value:"week"}, "This Week"),
        el("option", {value:"month"}, "This Month"),
        el("option", {value:"all"}, "All Time")
      )
    )
  );

  const kpis = el("div", {class:"grid2", style:"margin-top:12px"},
    el("div", {class:"card pad cardGlowPurple"},
      el("div", {class:"kpi"},
        el("div", {},
          el("div", {class:"label"}, "Practice Time"),
          el("div", {class:"value"}, fmtDuration(sum.totalSeconds)),
          el("div", {class:"small"}, "Tracked via drill timers (optional/forced)")
        ),
        el("div", {style:"text-align:right"},
          el("div", {class:"label"}, "Goal"),
          el("div", {class:"value"}, "—"),
          el("div", {class:"small"}, "Set later"
          )
        )
      )
    ),
    el("div", {class:"card pad cardGlowCyan"},
      el("div", {class:"kpi"},
        el("div", {},
          el("div", {class:"label"}, "Drills Practiced"),
          el("div", {class:"value"}, String(sum.drillCount)),
          el("div", {class:"small"}, "Total drill submissions")
        ),
        el("div", {style:"text-align:right"},
          el("div", {class:"label"}, "Streak"),
          el("div", {class:"value"}, "—"),
          el("div", {class:"small"}, "Add later")
        )
      )
    )
  );

  const dayRow = el("div", {class:"card pad", style:"margin-top:12px"},
    el("div", {class:"h3"}, "This Week"),
    el("div", {class:"hrRow"},
      ...wb.keys.map((k,i)=>el("div", {
        class:`dayPill ${k===activeDay?"active":""}`.trim(),
        onclick: ()=>{ activeDay=k; ctx.render(); }
      },
        weekdayShort(i),
        el("span", {class:"n"}, fmtDuration(wb.seconds[i]))
      ))
    )
  );

  const prog = el("div", {class:"card pad", style:"margin-top:12px"},
    el("div", {class:"h3"}, "All Drill Scores"),
    el("div", {style:"font-size:12px;color:var(--muted)"}, `Score progression · ${range === "week" ? "This Week" : (range==="month"?"This Month":"All Time")}`),
    el("div", {class:"divider"}),
    runs.length
      ? el("div", {style:"display:flex;flex-direction:column;gap:10px"},
          ...runs.slice(-8).reverse().map(r => {
            const d = drillsById[r.drillId];
            const title = d ? d.title : "Unknown drill";
            return el("div", {class:"card pad soft"},
              el("div", {style:"font-weight:700"}, title),
              el("div", {style:"font-size:12px;color:var(--muted);margin-top:2px"},
                `${r.makes}/${r.attempts} • ${Math.round(r.accuracy)}% • best streak ${r.bestStreak} • ${new Date(r.endedAt).toLocaleString()}`
              )
            );
          })
        )
      : el("div", {style:"font-size:13px;color:rgba(231,233,237,.78)"},
          "No drill scores yet. Run a drill from Browse to start tracking."
        )
  );

  const mostCard = el("div", {class:"card pad", style:"margin-top:12px"},
    el("div", {class:"h3"}, "Most Practiced Drills"),
    el("div", {class:"divider"}),
    most.length ? el("div", {style:"display:flex;flex-direction:column;gap:10px"},
      ...most.map(x=>el("div", {class:"kvRow"},
        el("div", {style:"font-size:13px"}, x.title),
        el("div", {style:"font-size:13px;font-weight:700"}, `${x.count}x`)
      ))
    ) : el("div", {style:"font-size:13px;color:rgba(231,233,237,.78)"}, "None yet.")
  );

  const balCard = el("div", {class:"card pad", style:"margin-top:12px"},
    el("div", {class:"h3"}, "What You Practiced"),
    el("div", {class:"divider"}),
    bal.length ? el("div", {style:"display:flex;flex-direction:column;gap:10px"},
      ...bal.map(x=>el("div", {class:"kvRow"},
        el("div", {style:"font-size:13px"}, x.tag),
        el("div", {style:"font-size:13px;font-weight:700"}, `${x.count}`)
      ))
    ) : el("div", {style:"font-size:13px;color:rgba(231,233,237,.78)"}, "No category data yet.")
  );

  return shell(el("div", {},
    header,
    kpis,
    dayRow,
    prog,
    mostCard,
    balCard
  ), "stats");
}
