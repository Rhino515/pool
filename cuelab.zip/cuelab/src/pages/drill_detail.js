import { el } from "../utils/dom.js";
import { shell } from "../components/layout.js";
import { chip, badge, btn, difficultyDot, formatDifficulty } from "../components/ui.js";
import { navigate } from "../router.js";
import { computeDrillStats } from "../store/store.js";

export function DrillDetailPage(ctx){
  const { state } = ctx;
  const id = ctx.route.query.id;
  const drill = (state.drills||[]).find(d=>d.id===id);
  if(!drill){
    return shell(el("div", {},
      el("div", {class:"h2"}, "Drill"),
      el("div", {class:"card pad"}, "Drill not found.")
    ), "browse");
  }

  const st = computeDrillStats(state, id);

  const diag = el("div", {class:"diagram", style:"height:180px"},
    drill.diagram?.type === "image"
      ? el("img", {src: drill.diagram.dataUrl, alt:"Diagram"})
      : el("div", {style:"font-size:12px;color:rgba(231,233,237,.7)"}, "No diagram yet (add in Edit)")
  );

  const top = el("div", {class:"card pad cardGlowCyan"},
    el("div", {class:"row", style:"justify-content:space-between;align-items:flex-start"},
      el("div", {},
        el("div", {class:"h2", style:"margin:0"}, drill.title),
        el("div", {style:"margin-top:8px", class:"row wrap"},
          el("div", {class:"difficulty"}, difficultyDot(drill.difficulty), formatDifficulty(drill.difficulty)),
          badge(`${drill.estimatedMinutes||0} min`),
          badge(`${drill.attemptsTotal||0} attempts`),
          badge(drill.timerMode === "forced" ? "Timer: forced" : (drill.timerMode === "optional" ? "Timer: optional" : "Timer: off"))
        )
      ),
      el("div", {class:"row"},
        btn("Edit", "smallBtn", ()=>navigate(`/drill/edit?id=${encodeURIComponent(id)}`))
      )
    ),
    el("div", {style:"margin-top:10px"}, diag),
    el("div", {style:"margin-top:10px"}, el("div", {class:"chips"}, ...(drill.tags||[]).map(chip))),
    el("div", {style:"margin-top:10px", class:"desc"}, drill.description || "")
  );

  const statsCard = el("div", {class:"card pad", style:"margin-top:12px"},
    el("div", {class:"h3"}, "Your Stats"),
    el("div", {class:"divider"}),
    el("div", {style:"display:flex;flex-direction:column;gap:10px"},
      el("div", {class:"kvRow"}, el("div", {class:"k"}, "Best accuracy"), el("div", {class:"v"}, `${Math.round(st.bestAccuracy||0)}%`)),
      el("div", {class:"kvRow"}, el("div", {class:"k"}, "Best streak ever"), el("div", {class:"v"}, String(st.bestStreakEver||0))),
      el("div", {class:"kvRow"}, el("div", {class:"k"}, "Last score"),
        el("div", {class:"v"}, st.last ? `${st.last.makes}/${st.last.attempts} (${Math.round(st.last.accuracy)}%)` : "—"
      ))
    )
  );

  const actions = el("div", {class:"card pad", style:"margin-top:12px"},
    btn("Start Drill", "primary full", ()=>navigate(`/run?id=${encodeURIComponent(id)}`))
  );

  return shell(el("div", {},
    el("div", {class:"h2"}, "Drill"),
    top,
    statsCard,
    actions
  ), "browse");
}
