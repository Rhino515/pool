import { el } from "../utils/dom.js";
import { shell } from "../components/layout.js";
import { btn } from "../components/ui.js";
import { toast } from "../utils/dom.js";

export function TableLabPage(ctx){
  const content = el("div", {},
    el("div", {class:"h2"}, "Table Lab"),
    el("div", {class:"card pad cardGlowCyan"},
      el("div", {style:"font-weight:800"}, "Coming next (Stage 3)"),
      el("div", {style:"font-size:13px;color:rgba(231,233,237,.78);margin-top:6px"},
        "This will be the WPB-style layout editor: blue cloth by default, switchable themes, drag balls, draw lines, snap-to-diamonds toggle, save to drills or library."
      ),
      el("div", {style:"margin-top:12px"},
        btn("Got it", "primary full", ()=>toast("Table Lab planned and ready to build next."))
      )
    )
  );

  return shell(content, "tools");
}
