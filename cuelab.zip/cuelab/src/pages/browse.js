import { el } from "../utils/dom.js";
import { shell } from "../components/layout.js";
import { chip, difficultyDot, formatDifficulty } from "../components/ui.js";
import { navigate } from "../router.js";
import { toast } from "../utils/dom.js";

const TABS = [
  {key:"drills", label:"Drills"},
  {key:"breaks", label:"Breaks"},
  {key:"kicks", label:"Kicks"},
  {key:"banks", label:"Banks"}
];

export function BrowsePage(ctx){
  const { state } = ctx;
  const tab = ctx.route.query.tab || "drills";

  const q = (ctx.route.query.q || "").toLowerCase();
  const tag = ctx.route.query.tag || "";
  const sort = ctx.route.query.sort || "popular"; // popular | newest | title

  const tagsAll = ["", ...new Set((state.drills||[]).flatMap(d=>d.tags||[]))].filter(Boolean);

  let drills = [...(state.drills || [])];

  // Simple tab filtering by tag shortcuts (optional)
  if(tab === "banks") drills = drills.filter(d => (d.tags||[]).includes("Banks"));
  if(tab === "kicks") drills = drills.filter(d => (d.tags||[]).includes("Kicks"));
  if(tab === "breaks") drills = drills.filter(d => (d.tags||[]).includes("Breaks"));

  if(q) drills = drills.filter(d =>
    (d.title||"").toLowerCase().includes(q) || (d.description||"").toLowerCase().includes(q)
  );
  if(tag) drills = drills.filter(d => (d.tags||[]).includes(tag));

  if(sort === "newest") drills.sort((a,b)=>new Date(b.updatedAt)-new Date(a.updatedAt));
  else if(sort === "title") drills.sort((a,b)=>(a.title||"").localeCompare(b.title||""));
  else {
    // "popular": by run count
    const counts = new Map();
    for(const r of (state.runs||[])) counts.set(r.drillId, (counts.get(r.drillId)||0)+1);
    drills.sort((a,b)=>(counts.get(b.id)||0) - (counts.get(a.id)||0));
  }

  const tabs = el("div", {class:"tabs"},
    ...TABS.map(t => el("div", {
      class:`tab ${t.key===tab?"active":""}`.trim(),
      onclick: ()=>navigate(`/browse?tab=${t.key}&q=${encodeURIComponent(ctx.route.query.q||"")}&tag=${encodeURIComponent(tag)}&sort=${encodeURIComponent(sort)}`)
    }, t.label))
  );

  const controls = el("div", {class:"card pad", style:"margin-top:12px"},
    el("div", {class:"row wrap"},
      el("input", {
        placeholder:"Search by title…",
        value: ctx.route.query.q || "",
        oninput: (e)=>navigate(`/browse?tab=${tab}&q=${encodeURIComponent(e.target.value)}&tag=${encodeURIComponent(tag)}&sort=${encodeURIComponent(sort)}`)
      }),
      el("select", {
        onchange: (e)=>navigate(`/browse?tab=${tab}&q=${encodeURIComponent(ctx.route.query.q||"")}&tag=${encodeURIComponent(e.target.value)}&sort=${encodeURIComponent(sort)}`)
      },
        el("option", {value:""}, "Filter tag"),
        ...tagsAll.map(t => el("option", {value:t, selected: t===tag}, t))
      ),
      el("select", {
        onchange: (e)=>navigate(`/browse?tab=${tab}&q=${encodeURIComponent(ctx.route.query.q||"")}&tag=${encodeURIComponent(tag)}&sort=${encodeURIComponent(e.target.value)}`)
      },
        el("option", {value:"popular", selected: sort==="popular"}, "Most Popular"),
        el("option", {value:"newest", selected: sort==="newest"}, "Newest"),
        el("option", {value:"title", selected: sort==="title"}, "Title A–Z")
      )
    )
  );

  const list = el("div", {style:"display:flex;flex-direction:column;gap:12px;margin-top:12px"},
    ...drills.map(d => drillCard(d))
  );

  const fab = el("div", {class:"fab", title:"Add drill", onclick: ()=>navigate("/drill/new")}, "+");

  return shell(el("div", {},
    el("div", {class:"h2"}, "Browse"),
    tabs,
    controls,
    list,
    fab
  ), "browse");

  function drillCard(d){
    const dot = difficultyDot(d.difficulty);
    const diag = el("div", {class:"diagram"},
      d.diagram?.type === "image"
        ? el("img", {src: d.diagram.dataUrl, alt:"Diagram"})
        : el("div", {style:"font-size:12px;color:rgba(231,233,237,.7)"}, "Diagram")
    );

    return el("div", {class:"card pad drillCard", onclick: ()=>navigate(`/drill?id=${encodeURIComponent(d.id)}`)},
      el("div", {class:"drillTop"},
        el("div", {class:"difficulty"}, dot, formatDifficulty(d.difficulty)),
        el("div", {class:"smallMeta"}, `${d.estimatedMinutes||0} min`)
      ),
      diag,
      el("div", {class:"chips"}, ...(d.tags||[]).slice(0,4).map(chip)),
      el("div", {class:"title"}, d.title || "Untitled Drill"),
      el("div", {class:"desc"}, d.description || "")
    );
  }
}
