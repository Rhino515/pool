import { el } from "../utils/dom.js";
import { shell } from "../components/layout.js";
import { btn, chip, inputRow } from "../components/ui.js";
import { navigate } from "../router.js";
import { upsertKnowledge, deleteKnowledge } from "../store/store.js";
import { toast } from "../utils/dom.js";
import { nowISO } from "../utils/time.js";

const SOURCES = ["My Notes","Tor Lowry","FXBilliards","Niels Feijen","Banking With The Beard","Sharivari","Books"];
const TYPES = ["System","Concept","Drill","Rules","Safety","Pattern"];

function uid(prefix="k"){
  return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now()}`;
}

export function LibraryPage(ctx){
  const { state } = ctx;
  const q = (ctx.route.query.q || "").toLowerCase();
  const source = ctx.route.query.source || "";
  const type = ctx.route.query.type || "";

  let items = [...(state.knowledge || [])];
  if(q) items = items.filter(k =>
    (k.title||"").toLowerCase().includes(q) ||
    (k.summary||"").toLowerCase().includes(q) ||
    (k.checklist||[]).join(" ").toLowerCase().includes(q)
  );
  if(source) items = items.filter(k => k.source === source);
  if(type) items = items.filter(k => k.type === type);

  const controls = el("div", {class:"card pad"},
    el("div", {class:"row wrap"},
      el("input", {
        placeholder:"Search notes…",
        value: ctx.route.query.q || "",
        oninput: (e)=>navigate(`/library?q=${encodeURIComponent(e.target.value)}&source=${encodeURIComponent(source)}&type=${encodeURIComponent(type)}`)
      }),
      el("select", {
        onchange:(e)=>navigate(`/library?q=${encodeURIComponent(ctx.route.query.q||"")}&source=${encodeURIComponent(e.target.value)}&type=${encodeURIComponent(type)}`)
      },
        el("option", {value:""}, "Source"),
        ...SOURCES.map(s=>el("option", {value:s, selected:s===source}, s))
      ),
      el("select", {
        onchange:(e)=>navigate(`/library?q=${encodeURIComponent(ctx.route.query.q||"")}&source=${encodeURIComponent(source)}&type=${encodeURIComponent(e.target.value)}`)
      },
        el("option", {value:""}, "Type"),
        ...TYPES.map(t=>el("option", {value:t, selected:t===type}, t))
      )
    ),
    el("div", {style:"margin-top:10px"},
      btn("Add Entry", "primary full", ()=>navigate("/library/new"))
    )
  );

  const list = el("div", {style:"display:flex;flex-direction:column;gap:12px;margin-top:12px"},
    ...items.map(k => el("div", {class:"card pad", onclick:()=>navigate(`/library/edit?id=${encodeURIComponent(k.id)}`)},
      el("div", {style:"display:flex;justify-content:space-between;gap:10px;align-items:flex-start"},
        el("div", {},
          el("div", {style:"font-weight:800"}, k.title || "Untitled"),
          el("div", {style:"font-size:12px;color:var(--muted);margin-top:2px"}, `${k.source || "—"} · ${k.type || "—"}`)
        ),
        el("div", {style:"font-size:12px;color:var(--muted)"}, (k.linkedDrillIds||[]).length ? `${k.linkedDrillIds.length} drills` : "")
      ),
      el("div", {style:"margin-top:8px", class:"chips"}, ...(k.tags||[]).slice(0,4).map(chip)),
      el("div", {style:"margin-top:8px", class:"desc"}, k.summary || "")
    ))
  );

  return shell(el("div", {},
    el("div", {class:"h2"}, "Knowledge Vault"),
    controls,
    list
  ), "tools");
}

export function LibraryEditPage(ctx){
  const { state, setState } = ctx;
  const id = ctx.route.query.id;
  const isNew = !id || id === "new";
  const existing = !isNew ? (state.knowledge||[]).find(k=>k.id===id) : null;

  const item = existing ? structuredClone(existing) : {
    id: uid("k"),
    title: "",
    source: "My Notes",
    type: "Concept",
    tags: [],
    summary: "",
    checklist: [],
    linkedDrillIds: [],
    createdAt: nowISO(),
    updatedAt: nowISO()
  };

  const title = el("input", {value:item.title, placeholder:"Title"});
  const source = el("select", {}, ...SOURCES.map(s=>el("option", {value:s, selected:item.source===s}, s)));
  const type = el("select", {}, ...TYPES.map(t=>el("option", {value:t, selected:item.type===t}, t)));
  const tags = el("input", {value:(item.tags||[]).join(", "), placeholder:"Tags (comma separated)"});
  const summary = el("textarea", {placeholder:"Summary (your own words)"}, item.summary || "");
  const checklist = el("textarea", {placeholder:"Checklist (one per line)"}, (item.checklist||[]).join("\n"));

  const drills = state.drills || [];
  const linkSel = el("select", {multiple:true, style:"width:100%;height:160px;padding:10px;border-radius:16px;"},
    ...drills.map(d => el("option", {value:d.id, selected:(item.linkedDrillIds||[]).includes(d.id)}, d.title))
  );

  const save = ()=>{
    item.title = title.value.trim() || "Untitled";
    item.source = source.value;
    item.type = type.value;
    item.tags = tags.value.split(",").map(s=>s.trim()).filter(Boolean);
    item.summary = summary.value.trim();
    item.checklist = checklist.value.split("\n").map(s=>s.trim()).filter(Boolean);
    item.linkedDrillIds = [...linkSel.selectedOptions].map(o=>o.value);

    const next = structuredClone(state);
    upsertKnowledge(next, item);
    setState(next);
    toast("Saved.");
    navigate("/library");
  };

  const del = ()=>{
    if(isNew){ navigate("/library"); return; }
    if(!confirm("Delete this knowledge entry?")) return;
    const next = structuredClone(state);
    deleteKnowledge(next, item.id);
    setState(next);
    toast("Deleted.");
    navigate("/library");
  };

  return shell(el("div", {},
    el("div", {class:"h2"}, isNew ? "Add Knowledge" : "Edit Knowledge"),
    el("div", {class:"card pad"},
      inputRow("Title", title),
      el("div", {class:"row wrap"},
        el("div", {style:"flex:1;min-width:180px"}, inputRow("Source", source)),
        el("div", {style:"flex:1;min-width:160px"}, inputRow("Type", type))
      ),
      inputRow("Tags", tags),
      inputRow("Summary", summary),
      inputRow("Checklist", checklist),
      el("div", {style:"font-size:12px;color:var(--muted);margin:10px 0 6px"}, "Link to drills"),
      linkSel,
      el("div", {style:"margin-top:14px", class:"btnRow"},
        btn("Save", "primary", save),
        btn(isNew ? "Cancel" : "Delete", isNew ? "" : "danger", del)
      )
    )
  ), "tools");
}
