import { dateKey, startOfWeek, addDays } from "./time.js";

export function filterRunsByRange(runs, range){
  const now = new Date();
  if(range === "all") return runs;
  if(range === "month"){
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    return runs.filter(r => new Date(r.endedAt) >= start);
  }
  // week
  const start = startOfWeek(now);
  return runs.filter(r => new Date(r.endedAt) >= start);
}

export function summarize(runs){
  const drillCount = runs.length;
  const totalSeconds = runs.reduce((a,r)=>a + (r.durationSeconds || 0), 0);
  return { drillCount, totalSeconds };
}

export function weekBuckets(runs){
  const start = startOfWeek(new Date());
  const days = Array.from({length:7}, (_,i)=>addDays(start,i));
  const keys = days.map(d=>dateKey(d));
  const map = new Map(keys.map(k=>[k,0]));
  for(const r of runs){
    const k = dateKey(new Date(r.endedAt));
    if(map.has(k)) map.set(k, map.get(k) + (r.durationSeconds || 0));
  }
  return { start, keys, seconds: keys.map(k=>map.get(k) || 0) };
}

export function mostPracticed(runs, drillsById){
  const m = new Map();
  for(const r of runs){
    m.set(r.drillId, (m.get(r.drillId)||0) + 1);
  }
  const items = [...m.entries()].map(([id,count])=>({
    id, count, title: drillsById[id]?.title || "Unknown"
  })).sort((a,b)=>b.count-a.count);
  return items.slice(0,6);
}

export function categoryBalance(runs, drillsById){
  const totals = new Map();
  for(const r of runs){
    const d = drillsById[r.drillId];
    if(!d) continue;
    const tags = d.tags || [];
    for(const t of tags){
      totals.set(t, (totals.get(t)||0) + 1);
    }
  }
  const items = [...totals.entries()].map(([tag,count])=>({tag,count}))
    .sort((a,b)=>b.count-a.count);
  return items.slice(0,8);
}
