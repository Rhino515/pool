export function el(tag, attrs = {}, ...children){
  const node = document.createElement(tag);
  for(const [k,v] of Object.entries(attrs || {})){
    if(k === "class") node.className = v;
    else if(k === "style") node.setAttribute("style", v);
    else if(k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if(v === false || v === null || v === undefined) continue;
    else node.setAttribute(k, String(v));
  }
  for(const ch of children.flat()){
    if(ch === null || ch === undefined || ch === false) continue;
    node.appendChild(typeof ch === "string" ? document.createTextNode(ch) : ch);
  }
  return node;
}

export function mount(root, child){
  root.innerHTML = "";
  root.appendChild(child);
}

export function toast(msg){
  const t = el("div", {style: `
    position:fixed; left:50%; bottom:110px; transform:translateX(-50%);
    background:rgba(15,22,32,.92); color:#e7e9ed;
    border:1px solid rgba(255,255,255,.12);
    padding:10px 12px; border-radius:14px; box-shadow:0 10px 28px rgba(0,0,0,.55);
    max-width:92vw; z-index:9999; font-size:13px;`}, msg);
  document.body.appendChild(t);
  setTimeout(()=>t.remove(), 2200);
}
