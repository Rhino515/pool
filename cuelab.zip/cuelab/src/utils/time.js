export function nowISO(){
  return new Date().toISOString();
}

export function dateKey(d = new Date()){
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth()+1).padStart(2,"0");
  const dd = String(d.getDate()).padStart(2,"0");
  return `${yyyy}-${mm}-${dd}`;
}

export function startOfWeek(d = new Date()){
  const x = new Date(d);
  const day = x.getDay(); // 0 Sun ... 6 Sat
  const diff = (day === 0 ? -6 : 1 - day); // Monday start
  x.setDate(x.getDate() + diff);
  x.setHours(0,0,0,0);
  return x;
}

export function addDays(d, n){
  const x = new Date(d);
  x.setDate(x.getDate()+n);
  return x;
}

export function fmtDuration(seconds){
  const s = Math.max(0, Math.floor(seconds || 0));
  const h = Math.floor(s/3600);
  const m = Math.floor((s%3600)/60);
  if(h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

export function weekdayShort(i){
  return ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i] || "";
}
