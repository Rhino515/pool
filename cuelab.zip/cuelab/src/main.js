import { mount } from "./utils/dom.js";
import { addRoute, getRoute, onRouteChange, navigate } from "./router.js";
import { loadState, saveState } from "./store/store.js";

import { HomePage } from "./pages/home.js";
import { StatsPage } from "./pages/stats.js";
import { BrowsePage } from "./pages/browse.js";
import { ToolsPage } from "./pages/tools.js";
import { DrillDetailPage } from "./pages/drill_detail.js";
import { DrillRunPage, DrillRunResultPage } from "./pages/drill_run.js";
import { DrillEditPage } from "./pages/drill_edit.js";
import { LibraryPage, LibraryEditPage } from "./pages/library.js";
import { TableLabPage } from "./pages/table_lab.js";
import { BackupPage, RestorePage } from "./pages/tools_data.js";

// PWA service worker
if("serviceWorker" in navigator){
  window.addEventListener("load", async ()=>{
    try{ await navigator.serviceWorker.register("./sw.js"); }catch{}
  });
}

const app = document.getElementById("app");
let state = loadState();

function setState(next){
  state = next;
  saveState(state);
  render();
}

function render(){
  const route = getRoute();
  const ctx = { state, setState, route, render };
  const handler = routes.get(route.path) || routes.get("/home");
  const view = handler(ctx);
  mount(app, view);
}

const routes = new Map();
function route(path, handler){ routes.set(path, handler); }

// Routes
route("/", (ctx)=>HomePage(ctx));        // Learn tab points here (WPB style)
route("/home", (ctx)=>HomePage(ctx));
route("/stats", (ctx)=>StatsPage(ctx));
route("/browse", (ctx)=>BrowsePage(ctx));
route("/tools", (ctx)=>ToolsPage(ctx));

route("/drill", (ctx)=>DrillDetailPage(ctx));
route("/drill/new", (ctx)=>DrillEditPage({ ...ctx, route:{path:"/drill/new", query:{id:"new"}} }));
route("/drill/edit", (ctx)=>DrillEditPage(ctx));

route("/run", (ctx)=>DrillRunPage(ctx));
route("/run/result", (ctx)=>DrillRunResultPage(ctx));

route("/library", (ctx)=>LibraryPage(ctx));
route("/library/new", (ctx)=>LibraryEditPage({ ...ctx, route:{path:"/library/new", query:{id:"new"}} }));
route("/library/edit", (ctx)=>LibraryEditPage(ctx));

route("/table-lab", (ctx)=>TableLabPage(ctx));

route("/backup", (ctx)=>BackupPage(ctx));
route("/restore", (ctx)=>RestorePage(ctx));

// boot
onRouteChange(render);
if(!location.hash) navigate("/home");
render();
