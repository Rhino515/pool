// Very small hash router
const routes = new Map();

export function addRoute(path, handler){
  routes.set(path, handler);
}

export function getRoute(){
  const hash = location.hash || "#/";
  const [path, qs] = hash.slice(1).split("?");
  const query = Object.fromEntries(new URLSearchParams(qs || ""));
  return { path: path || "/", query };
}

export function navigate(path){
  location.hash = `#${path.startsWith("/") ? path : "/"+path}`;
}

export function onRouteChange(fn){
  window.addEventListener("hashchange", fn);
}
